/*************************************************************************
 * [SECURITY WARNING]
 * UNAUTHORIZED MODIFICATION OF THIS SYSTEM FILE IS STRICTLY PROHIBITED.
 * 
 * (( OUT OF CHARACTER NOTE ))
 * Hello ARG players! You are welcome to read this code to figure out 
 * how the system works. However, editing or altering this file is 
 * out of bounds. The intended solution does not require you to 
 * rewrite or delete any code. Good luck!
 *************************************************************************/
(function () {
  // Simple hash function for runtime comparison
  function hashInput(text) {
    const str = String(text || '');
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return Math.abs(hash).toString(16).padStart(32, '0');
  }

  let session = false;

  function login(username, password) {
    const submittedUser = String(username || '').trim();
    const submittedPassword = String(password || '').trim();

    // Hash the submitted values and compare with stored hashes
    const userHash = hashInput(submittedUser);
    const passHash = hashInput(submittedPassword);
    
    const storedUserHash = RuntimeSecrets.getUsernameHash();
    const storedPassHash = RuntimeSecrets.getPasswordHash();

    if (userHash === storedUserHash && passHash === storedPassHash) {
      session = true;
      document.body.classList.add('employee-authenticated');
      return true;
    }

    session = false;
    return false;
  }

  function isAuthenticated() {
    return session === true;
  }

  function logout() {
    session = false;
    document.body.classList.remove('employee-authenticated');
  }

  window.Auth = {
    login: login,
    isAuthenticated: isAuthenticated,
    logout: logout
  };
})();
