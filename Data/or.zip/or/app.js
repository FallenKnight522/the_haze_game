/*************************************************************************
 * [SECURITY WARNING]
 * UNAUTHORIZED MODIFICATION OF THIS SYSTEM FILE IS STRICTLY PROHIBITED.
 * 
 * (( OUT OF CHARACTER NOTE ))
 * Hello ARG players! You are welcome to read this code to figure out 
 * how the system works. However, editing or altering this file is 
 * out of bounds. The intended solution does not require you to 
 * rewrite or delete any code. Good luck!
 *************************************************************************/

/* Full app.js implementation moved to webside/js/app.js */
(function () {
  let renderGeneration = 0;

  function uiText(sectionId) {
    const source = window.IPR_CONTENT_DATA && window.IPR_CONTENT_DATA.public;
    return MarkdownRenderer.findSection(source, sectionId).trim();
  }

  function applyHeaderText() {
    document.title = uiText('UI_BRAND_NAME');
    document.querySelector('.brand-wrap').setAttribute('aria-label', uiText('UI_BRAND_HOME'));
    document.querySelector('.main-nav').setAttribute('aria-label', uiText('UI_MAIN_NAV'));
    document.querySelector('.brand-name').textContent = uiText('UI_BRAND_NAME');
    document.querySelector('.brand-subtitle').textContent = uiText('UI_BRAND_SUBTITLE');
    document.querySelectorAll('.main-nav .nav-link').forEach(function (button) {
      button.textContent = uiText(button.dataset.uiKey);
    });
  }

  function setAppContent(node) {
    const app = document.getElementById('app');
    if (!app) {
      return;
    }
    app.innerHTML = '';
    if (node) {
      app.appendChild(node);
    }
  }

  function renderPublicPage(route) {
    const sectionId = Router.sectionIdFor(route);
    const source = 'public';
    const generation = renderGeneration;
    ContentLoader.load(source).then(function (markdownText) {
      if (generation !== renderGeneration || Router.currentRoute() !== route) {
        return;
      }
      const rendered = MarkdownRenderer.render(markdownText, sectionId);
      if (route === 'contact') {
        rendered.appendChild(renderContactForm());
      }
      setAppContent(rendered);
    }).catch(function (error) {
      if (generation !== renderGeneration || Router.currentRoute() !== route) {
        return;
      }
      const message = document.createElement('p');
      message.className = 'status-block error';
      message.textContent = uiText('UI_PAGE_UNAVAILABLE');
      setAppContent(message);
    });
  }

  function buildLoginView() {
    const panel = document.createElement('section');
    panel.className = 'login-panel';

    const title = document.createElement('h1');
    title.textContent = uiText('UI_LOGIN_TITLE');
    panel.appendChild(title);

    const form = document.createElement('form');
    form.className = 'form-grid';

    const userWrap = document.createElement('div');
    const userLabel = document.createElement('label');
    userLabel.textContent = uiText('UI_LOGIN_USERNAME');
    const userInput = document.createElement('input');
    userInput.type = 'text';
    userInput.name = 'username';
    userInput.autocomplete = 'username';
    userWrap.appendChild(userLabel);
    userWrap.appendChild(userInput);

    const passWrap = document.createElement('div');
    const passLabel = document.createElement('label');
    passLabel.textContent = uiText('UI_LOGIN_PASSWORD');
    const passInput = document.createElement('input');
    passInput.type = 'password';
    passInput.name = 'password';
    passInput.autocomplete = 'current-password';
    passWrap.appendChild(passLabel);
    passWrap.appendChild(passInput);

    const submit = document.createElement('button');
    submit.type = 'submit';
    submit.className = 'primary';
    submit.textContent = uiText('UI_LOGIN_SUBMIT');

    const message = document.createElement('div');
    message.className = 'status-block hidden';
    message.setAttribute('role', 'alert');

    form.addEventListener('submit', function (event) {
      event.preventDefault();
      const ok = Auth.login(userInput.value, passInput.value);
      if (ok) {
        message.className = 'status-block success';
        message.textContent = uiText('UI_LOGIN_GRANTED');
        Router.navigate('internal/research');
        return;
      }
      message.className = 'status-block error';
      message.textContent = uiText('UI_LOGIN_DENIED');
    });

    form.appendChild(userWrap);
    form.appendChild(passWrap);
    form.appendChild(submit);
    form.appendChild(message);
    panel.appendChild(form);
    return panel;
  }

  function renderInternalPortal(route) {
    const wrapper = document.createElement('div');
    wrapper.className = 'portal-layout';

    const content = document.createElement('section');
    content.className = 'portal-panel';
    const contentMount = document.createElement('div');
    contentMount.className = 'internal-content';
    const side = document.createElement('aside');
    side.className = 'portal-panel';

    const title = document.createElement('h1');
    title.textContent = uiText('UI_PORTAL_TITLE');
    content.appendChild(title);

    const nav = document.createElement('nav');
    [
      ['internal/research', 'UI_NAV_RESEARCH'],
      ['internal/field-research', 'UI_NAV_FIELD_RESEARCH'],
      ['internal/containment', 'UI_NAV_CONTAINMENT'],
      ['internal/archival', 'UI_NAV_ARCHIVAL'],
      ['internal/statement', 'UI_NAV_STATEMENT'],
      ['internal/cipher', 'UI_NAV_CIPHER']
    ].forEach(function (item) {
      const button = document.createElement('button');
      button.className = 'nav-link';
      button.dataset.route = item[0];
      button.textContent = uiText(item[1]);
      nav.appendChild(button);
    });
    content.appendChild(nav);

    const info = document.createElement('div');
    info.className = 'status-block';
    info.textContent = uiText('UI_PORTAL_STATUS');
    content.appendChild(info);
    content.appendChild(contentMount);

    const logout = document.createElement('button');
    logout.type = 'button';
    logout.className = 'secondary';
    logout.textContent = uiText('UI_LOGOUT');
    logout.addEventListener('click', function () {
      Auth.logout();
      Router.navigate('login');
    });
    side.appendChild(logout);

    if (route === 'internal/statement') {
      side.appendChild(renderStatementForm());
    }
    if (route === 'internal/cipher') {
      side.appendChild(renderCipherForm());
    }

    wrapper.appendChild(content);
    wrapper.appendChild(side);
    return { wrapper: wrapper, contentMount: contentMount };
  }

  function renderNotFound() {
    const panel = document.createElement('section');
    panel.className = 'article-panel';
    const heading = document.createElement('h1');
    heading.textContent = uiText('UI_PAGE_NOT_FOUND');
    const message = document.createElement('p');
    message.textContent = uiText('UI_RECORD_UNAVAILABLE');
    panel.appendChild(heading);
    panel.appendChild(message);
    return panel;
  }

  function renderContactForm() {
    const card = document.createElement('section');
    card.className = 'form-card';

    const heading = document.createElement('h2');
    heading.textContent = uiText('UI_CONTACT_TITLE');
    card.appendChild(heading);

    const form = document.createElement('form');
    form.className = 'form-grid';
    [
      ['UI_CONTACT_NAME', 'contact-name', 'text'],
      ['UI_CONTACT_EMAIL', 'contact-email', 'email'],
      ['UI_CONTACT_MESSAGE', 'contact-message', 'text']
    ].forEach(function (field) {
      const wrapper = document.createElement('div');
      const label = document.createElement('label');
      label.textContent = uiText(field[0]);
      label.setAttribute('for', field[1]);
      const input = document.createElement(field[0] === 'UI_CONTACT_MESSAGE' ? 'textarea' : 'input');
      input.id = field[1];
      input.name = field[1];
      if (field[2] !== 'text') input.type = field[2];
      input.required = true;
      wrapper.appendChild(label);
      wrapper.appendChild(input);
      form.appendChild(wrapper);
    });

    const submit = document.createElement('button');
    submit.type = 'submit';
    submit.className = 'submit';
    submit.textContent = uiText('UI_CONTACT_SUBMIT');
    const message = document.createElement('div');
    message.className = 'status-block hidden';
    message.setAttribute('role', 'status');
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      message.className = 'status-block';
      message.textContent = uiText('UI_CONTACT_OFFLINE');
    });
    form.appendChild(submit);
    form.appendChild(message);
    card.appendChild(form);
    return card;
  }

  function renderStatementForm() {
    const card = document.createElement('section');
    card.className = 'form-card';
    const heading = document.createElement('h2');
    heading.textContent = uiText('UI_STATEMENT_TITLE');
    card.appendChild(heading);

    const form = document.createElement('form');
    form.className = 'form-grid';

    const fields = [
      { key: 'name', label: 'UI_STATEMENT_NAME', tag: 'input', type: 'text' },
      { key: 'date', label: 'UI_STATEMENT_DATE', tag: 'input', type: 'date' },
      { key: 'subject', label: 'UI_STATEMENT_SUBJECT', tag: 'input', type: 'text' },
      { key: 'text', label: 'UI_STATEMENT_TEXT', tag: 'textarea' }
    ];

    const inputs = {};
    fields.forEach(function (field) {
      const wrapper = document.createElement('div');
      const label = document.createElement('label');
      label.textContent = uiText(field.label);
      label.setAttribute('for', field.key);
      const input = document.createElement(field.tag);
      input.id = field.key;
      input.name = field.key;
      if (field.type) input.type = field.type;
      inputs[field.key] = input;
      wrapper.appendChild(label);
      wrapper.appendChild(input);
      form.appendChild(wrapper);
    });

    const submit = document.createElement('button');
    submit.type = 'submit';
    submit.className = 'submit';
    submit.textContent = uiText('UI_STATEMENT_SUBMIT');

    const warning = document.createElement('div');
    warning.className = 'status-block hidden';
    warning.setAttribute('role', 'status');

    form.addEventListener('submit', function (event) {
      event.preventDefault();
      const statement = {
        name: inputs.name.value,
        date: inputs.date.value,
        subject: inputs.subject.value,
        text: inputs.text.value
      };
      const ok = StatementExporter.export(statement);
      if (ok) {
        warning.className = 'status-block';
        warning.textContent = uiText('UI_STATEMENT_SUCCESS');
      } else {
        warning.className = 'status-block error';
        warning.textContent = uiText('UI_REQUIRED_FIELDS');
      }
    });

    form.appendChild(submit);
    form.appendChild(warning);
    card.appendChild(form);
    return card;
  }

  function renderCipherForm() {
    const card = document.createElement('section');
    card.className = 'cipher-card';
    const heading = document.createElement('h2');
    heading.textContent = uiText('UI_CIPHER_TITLE');
    card.appendChild(heading);

    const textarea = document.createElement('textarea');
    textarea.placeholder = uiText('UI_CIPHER_PLACEHOLDER');

    const actions = document.createElement('div');
    actions.className = 'form-grid';

    const encodeBtn = document.createElement('button');
    encodeBtn.type = 'button';
    encodeBtn.className = 'secondary';
    encodeBtn.textContent = uiText('UI_CIPHER_ENCODE');

    const decodeBtn = document.createElement('button');
    decodeBtn.type = 'button';
    decodeBtn.className = 'secondary';
    decodeBtn.textContent = uiText('UI_CIPHER_DECODE');

    const output = document.createElement('div');
    output.className = 'status-block';
    output.setAttribute('role', 'status');
    output.textContent = uiText('UI_CIPHER_READY');

    encodeBtn.addEventListener('click', function () {
      const encoded = Cipher.encode(textarea.value);
      output.className = 'status-block';
      output.textContent = encoded;
    });

    decodeBtn.addEventListener('click', function () {
      const result = Cipher.decode(textarea.value);
      if (!result.ok) {
        if (result.anomaly) {
          output.className = 'status-block error';
          output.textContent = uiText('UI_CIPHER_ANOMALY');
        } else {
          output.className = 'status-block error';
          output.textContent = uiText('UI_CIPHER_MALFORMED');
        }
        return;
      }
      output.className = 'status-block success';
      output.textContent = result.text;
    });

    actions.appendChild(encodeBtn);
    actions.appendChild(decodeBtn);
    card.appendChild(textarea);
    card.appendChild(actions);
    card.appendChild(output);
    return card;
  }

  function renderRoute() {
    renderGeneration += 1;
    const route = Router.currentRoute();
    const isInternal = Router.isInternalRoute(route);

    if (!Router.isKnownRoute(route)) {
      if (isInternal && !Auth.isAuthenticated()) {
        Router.navigate('login');
        return;
      }
      setAppContent(renderNotFound());
      return;
    }

    if (route === 'login') {
      setAppContent(buildLoginView());
      return;
    }

    if (isInternal) {
      if (!Auth.isAuthenticated()) {
        Router.navigate('login');
        setAppContent(buildLoginView());
        return;
      }
      const internalRoute = route;
      if (internalRoute === 'internal/research' || internalRoute === 'internal/field-research' || internalRoute === 'internal/containment' || internalRoute === 'internal/archival' || internalRoute === 'internal/statement' || internalRoute === 'internal/cipher') {
        const portalView = renderInternalPortal(internalRoute);
        const sectionId = Router.sectionIdFor(internalRoute);
        const generation = renderGeneration;
        ContentLoader.load('internal').then(function (markdownText) {
          if (generation !== renderGeneration || Router.currentRoute() !== internalRoute) {
            return;
          }
          const rendered = MarkdownRenderer.render(markdownText, sectionId);
          portalView.contentMount.appendChild(rendered);
          setAppContent(portalView.wrapper);
          bindNav();
          updateActiveNavigation();
        }).catch(function () {
          if (generation !== renderGeneration || Router.currentRoute() !== internalRoute) {
            return;
          }
          const errorMessage = document.createElement('div');
          errorMessage.className = 'status-block error';
          errorMessage.textContent = uiText('UI_INTERNAL_UNAVAILABLE');
          portalView.contentMount.appendChild(errorMessage);
          setAppContent(portalView.wrapper);
          bindNav();
          updateActiveNavigation();
        });
      }
      return;
    }

    renderPublicPage(route);
  }

  function bindNav() {
    document.querySelectorAll('.nav-link').forEach(function (button) {
      if (button.dataset.bound === 'true') {
        return;
      }
      button.dataset.bound = 'true';
      button.addEventListener('click', function () {
        const route = button.getAttribute('data-route');
        Router.navigate(route);
      });
    });
  }

  function updateActiveNavigation() {
    document.querySelectorAll('.nav-link').forEach(function (button) {
      const route = button.getAttribute('data-route');
      button.classList.toggle('active', Router.currentRoute() === route);
    });
  }

  function applyAuthState() {
    document.body.classList.toggle('employee-authenticated', Auth.isAuthenticated());
  }

  function handleHashChange() {
    applyAuthState();
    renderRoute();
    bindNav();
    updateActiveNavigation();
  }

  window.addEventListener('hashchange', handleHashChange);
  document.addEventListener('DOMContentLoaded', function () {
    applyHeaderText();
    handleHashChange();
  });
})();
