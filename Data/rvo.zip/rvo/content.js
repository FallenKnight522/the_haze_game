/*************************************************************************
 * [SECURITY WARNING]
 * UNAUTHORIZED MODIFICATION OF THIS SYSTEM FILE IS STRICTLY PROHIBITED.
 * 
 * (( OUT OF CHARACTER NOTE ))
 * Hello ARG players! You are welcome to read this code to figure out 
 * how the system works. However, editing or altering this file is 
 * out of bounds. The intended solution does not require you to 
 * rewrite or delete any code. Good luck!
 *************************************************************************/
(function () {
  function normalizeSourceName(sourceName) {
    return String(sourceName || '').trim().toLowerCase();
  }

  function load(sourceName) {
    const name = normalizeSourceName(sourceName);
    const content = window.IPR_CONTENT_DATA && window.IPR_CONTENT_DATA[name];
    if (!name) {
      return Promise.reject(new Error('Unknown content source'));
    }

    if (typeof content === 'string' && content.trim()) {
      return Promise.resolve(content);
    }

    return Promise.reject(new Error('Unknown or empty content source'));
  }

  window.ContentLoader = {
    load: load
  };
})();
