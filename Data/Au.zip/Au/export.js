/*************************************************************************
 * [SECURITY WARNING]
 * UNAUTHORIZED MODIFICATION OF THIS SYSTEM FILE IS STRICTLY PROHIBITED.
 * 
 * (( OUT OF CHARACTER NOTE ))
 * Hello ARG players! You are welcome to read this code to figure out 
 * how the system works. However, editing or altering this file is 
 * out of bounds. The intended solution does not require you to 
 * rewrite or delete any code. Good luck!
 *************************************************************************/
(function () {
  function normalizeStatement(statement) {
    const cleaned = {
      name: String(statement && statement.name ? statement.name : '').trim(),
      date: String(statement && statement.date ? statement.date : '').trim(),
      subject: String(statement && statement.subject ? statement.subject : '').trim(),
      text: String(statement && statement.text ? statement.text : '').trim()
    };

    return cleaned;
  }

  function exportStatement(statement) {
    const record = normalizeStatement(statement);
    const missing = [];
    if (!record.name) missing.push('Subject name');
    if (!record.date) missing.push('Date of experience');
    if (!record.subject) missing.push('Statement subject');
    if (!record.text) missing.push('Full statement');

    if (missing.length > 0) {
      window.dispatchEvent(new CustomEvent('ipr-export-error', { detail: { missing: missing } }));
      return false;
    }

    const output = [
      'IPR STATEMENT RECORD',
      '====================',
      '',
      'Subject name: ' + record.name,
      'Date of experience: ' + record.date,
      'Statement subject: ' + record.subject,
      '',
      'Full statement:',
      record.text.replace(/\r\n/g, '\n')
    ].join('\n');

    const blob = new Blob([output], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = 'ipr-statement.txt';
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);

    window.dispatchEvent(new CustomEvent('ipr-export-warning', { detail: {
      message: 'The offline copy could not reach the company database. The statement has been saved locally only.'
    } }));

    return true;
  }

  window.StatementExporter = {
    export: exportStatement
  };
})();
