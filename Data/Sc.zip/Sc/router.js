/*************************************************************************
 * [SECURITY WARNING]
 * UNAUTHORIZED MODIFICATION OF THIS SYSTEM FILE IS STRICTLY PROHIBITED.
 * 
 * (( OUT OF CHARACTER NOTE ))
 * Hello ARG players! You are welcome to read this code to figure out 
 * how the system works. However, editing or altering this file is 
 * out of bounds. The intended solution does not require you to 
 * rewrite or delete any code. Good luck!
 *************************************************************************/
(function () {
  const ROUTE_MAP = {
    home: 'PUBLIC_HOME',
    history: 'PUBLIC_HISTORY',
    mission: 'PUBLIC_MISSION',
    statements: 'PUBLIC_STATEMENTS',
    contact: 'PUBLIC_CONTACT',
    archives: 'PUBLIC_ARCHIVES',
    funding: 'PUBLIC_FUNDING',
    careers: 'PUBLIC_CAREERS',
    login: 'LOGIN',
    'internal/research': 'INTERNAL_RESEARCH',
    'internal/field-research': 'INTERNAL_FIELD_RESEARCH',
    'internal/containment': 'INTERNAL_CONTAINMENT',
    'internal/archival': 'INTERNAL_ARCHIVAL',
    'internal/statement': 'INTERNAL_STATEMENT',
    'internal/cipher': 'INTERNAL_CIPHER'
  };

  function normalizeRoute(route) {
    const raw = String(route || '').trim();
    if (!raw || raw === '#') {
      return 'home';
    }
    return raw.replace(/^#/, '').replace(/\/$/, '').trim() || 'home';
  }

  function currentRoute() {
    return normalizeRoute(window.location.hash || '#home');
  }

  function navigate(route) {
    const normalized = normalizeRoute(route);
    window.location.hash = normalized;
  }

  function isInternalRoute(route) {
    const normalized = normalizeRoute(route);
    return normalized.indexOf('internal/') === 0;
  }

  function sectionIdFor(route) {
    return ROUTE_MAP[normalizeRoute(route)] || 'PUBLIC_HOME';
  }

  function isKnownRoute(route) {
    return Object.prototype.hasOwnProperty.call(ROUTE_MAP, normalizeRoute(route));
  }

  window.Router = {
    currentRoute: currentRoute,
    navigate: navigate,
    isInternalRoute: isInternalRoute,
    isKnownRoute: isKnownRoute,
    sectionIdFor: sectionIdFor
  };
})();
