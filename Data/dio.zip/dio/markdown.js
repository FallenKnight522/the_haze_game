/*************************************************************************
 * [SECURITY WARNING]
 * UNAUTHORIZED MODIFICATION OF THIS SYSTEM FILE IS STRICTLY PROHIBITED.
 * 
 * (( OUT OF CHARACTER NOTE ))
 * Hello ARG players! You are welcome to read this code to figure out 
 * how the system works. However, editing or altering this file is 
 * out of bounds. The intended solution does not require you to 
 * rewrite or delete any code. Good luck!
 *************************************************************************/
(function () {
  function escapeHtml(value) {
    return String(value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/\"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function formatInline(text) {
    let formatted = escapeHtml(text);
    formatted = formatted.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    formatted = formatted.replace(/\*(.+?)\*/g, '<em>$1</em>');
    formatted = formatted.replace(/\[(.+?)\]\((.+?)\)/g, function (match, label, url) {
      const safeUrl = /^(#|\.?\/?[a-z0-9_./-]+$)/i.test(url.trim()) ? url.trim() : '#';
      return '<a href="' + escapeHtml(safeUrl) + '" target="_self">' + label + '</a>';
    });
    return formatted;
  }

  function findSection(markdownText, sectionId) {
    const lines = String(markdownText || '').split(/\r?\n/);
    const target = String(sectionId || '').trim();
    let capture = false;
    const collected = [];

    for (let index = 0; index < lines.length; index += 1) {
      const line = lines[index];
      const headingMatch = line.match(/^(#{1,6})\s*(.+?)\s*$/);

      if (headingMatch) {
        const headingText = headingMatch[2].trim();
        if (headingText === target) {
          capture = true;
          continue;
        }
        if (capture && /^(PUBLIC|INTERNAL|UI|LOGIN)_[A-Z0-9_]+$/.test(headingText)) {
          break;
        }
      }

      if (capture) {
        collected.push(line);
      }
    }

    if (!capture || collected.length === 0) {
      return '';
    }

    return collected.join('\n');
  }

  function render(markdownText, sectionId) {
    const wrapper = document.createElement('article');
    wrapper.className = 'article-panel';

    const content = findSection(markdownText, sectionId);
    if (!content) {
      const fallback = document.createElement('p');
      fallback.className = 'status-block error';
      const uiSource = window.IPR_CONTENT_DATA && window.IPR_CONTENT_DATA.public;
      fallback.textContent = MarkdownRenderer.findSection(uiSource, 'UI_SECTION_UNAVAILABLE').trim() || 'This section is currently unavailable.';
      wrapper.appendChild(fallback);
      return wrapper;
    }

    const lines = content.split(/\r?\n/);
    const fragment = document.createDocumentFragment();
    let listBuffer = [];
    let inList = false;

    function flushList() {
      if (!inList || listBuffer.length === 0) {
        return;
      }
      const listEl = document.createElement('ul');
      listBuffer.forEach(function (item) {
        const li = document.createElement('li');
        li.innerHTML = formatInline(item);
        listEl.appendChild(li);
      });
      fragment.appendChild(listEl);
      listBuffer = [];
      inList = false;
    }

    for (let index = 0; index < lines.length; index += 1) {
      const line = lines[index];
      const headingMatch = line.match(/^(#{1,6})\s*(.+?)\s*$/);
      if (headingMatch) {
        flushList();
        const level = headingMatch[1].length;
        const heading = document.createElement('h' + level);
        heading.innerHTML = formatInline(headingMatch[2].trim());
        fragment.appendChild(heading);
        continue;
      }

      if (!line.trim()) {
        flushList();
        continue;
      }

      if (line.match(/^\s*[-*]/)) {
        inList = true;
        listBuffer.push(line.replace(/^\s*[-*]\s*/, ''));
        continue;
      }

      flushList();
      const para = document.createElement('p');
      para.innerHTML = formatInline(line);
      fragment.appendChild(para);
    }

    flushList();
    wrapper.appendChild(fragment);
    return wrapper;
  }

  window.MarkdownRenderer = {
    render: render,
    findSection: findSection,
    escapeHtml: escapeHtml
  };
})();
