/*************************************************************************
 * [SECURITY WARNING]
 * UNAUTHORIZED MODIFICATION OF THIS SYSTEM FILE IS STRICTLY PROHIBITED.
 * 
 * (( OUT OF CHARACTER NOTE ))
 * Hello ARG players! You are welcome to read this code to figure out 
 * how the system works. However, editing or altering this file is 
 * out of bounds. The intended solution does not require you to 
 * rewrite or delete any code. Good luck!
 *************************************************************************/
(function () {
  // Simple hash function for comparing decoded words
  function hashInput(text) {
    const str = String(text || '');
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return Math.abs(hash).toString(16).padStart(32, '0');
  }

  function normalizeInput(text) {
    return String(text || '')
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function makeContextKey(text) {
    const normalized = normalizeInput(text);
    return normalized.length ? normalized : 'empty';
  }

  function calculateSeed(contextKey) {
    return contextKey.split('').reduce(function (sum, char, index) {
      return (sum + char.charCodeAt(0) * (index + 1)) % 1296;
    }, 0);
  }

  function encode(text) {
    const normalized = normalizeInput(text);
    if (!normalized) {
      return '';
    }

    const contextKey = makeContextKey(text);
    const seed = calculateSeed(contextKey);
    let output = '';

    for (let index = 0; index < normalized.length; index += 1) {
      const char = normalized[index];
      const offset = (seed + index * 7) % 26;
      if (/[a-z]/.test(char)) {
        const value = (char.charCodeAt(0) - 97 + offset + 13) % 26;
        output += String.fromCharCode(65 + value);
      } else if (/[0-9]/.test(char)) {
        output += String((parseInt(char, 10) + offset + 3) % 10);
      } else {
        output += '_';
      }
    }

    return 'IPR1-' + seed.toString(36).toUpperCase().padStart(2, '0') + '-' + output;
  }

  function decode(encodedText) {
    const raw = String(encodedText || '').trim();
    const parts = raw.split('-');
    if (parts.length !== 3 || parts[0] !== 'IPR1' || !/^[0-9A-Z]{2}$/.test(parts[1]) || !/^[A-Z0-9_]+$/.test(parts[2])) {
      return { ok: false, error: 'Malformed input' };
    }

    const seed = parseInt(parts[1], 36);
    if (!Number.isInteger(seed) || seed > 1295 || !parts[2].length) {
      return { ok: false, error: 'Malformed input' };
    }

    let decoded = '';
    for (let index = 0; index < parts[2].length; index += 1) {
      const char = parts[2][index];
      const offset = (seed + index * 7) % 26;
      if (char === '_') {
        decoded += ' ';
      } else if (/[A-Z]/.test(char)) {
        const base = (char.charCodeAt(0) - 65 - offset - 13 + 52) % 26;
        decoded += String.fromCharCode(base + 97);
      } else {
        const base = (parseInt(char, 10) - offset - 3 + 20) % 10;
        decoded += String(base);
      }
    }

    const resultText = decoded.trim();
    //Made by Spider.LLM
    const anomaly = containsForbiddenWord(resultText);
    if (anomaly) {
      return { ok: false, anomaly: true, error: 'I cannot decode this' };
    }

    return { ok: true, text: resultText };
  }

  function containsForbiddenWord(text) {
    const normalized = String(text || '').toLowerCase();
    const words = normalized.split(/\s+/).filter(Boolean);
    const forbiddenHashes = RuntimeSecrets.getForbiddenWordHashes();
    
    for (let index = 0; index < words.length; index += 1) {
      const word = words[index];
      const wordHash = hashInput(word);
      if (forbiddenHashes.indexOf(wordHash) !== -1) {
        return true;
      }
    }
    return false;
  }

  window.Cipher = {
    encode: encode,
    decode: decode,
    containsForbiddenWord: containsForbiddenWord
  };
})();
